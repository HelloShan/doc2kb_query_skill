#!/usr/bin/env python3
"""
doc2kb — 文档转换引擎模块（优化版）

【改动说明】
==========
这是恢复版本 81ed0f8 的基础上，进行的优化改动：

1. 模型缓存优化
   - 在 docling_worker.py 子进程中缓存 Docling 模型
   - 避免每个文件都重新加载模型（这是新版本 81a8879 的问题）
   - 但保留子进程隔离（这是旧版本 81ed0f8 的优势）

2. 内存管理改进
   - 及时释放大对象引用
   - 更严格的文件大小检查
   - 更好的错误恢复

3. 代码简化
   - 去除冗余的异常处理
   - 统一的子进程超时逻辑
   - 更清晰的函数签名

【性能对比】
==========
旧版本 81ed0f8: 子进程隔离 ✓，但模型每文件重新加载
优化版本：      子进程隔离 ✓，模型在 worker 中缓存 ✓✓
新版本 81a8879: 主进程直接运行，大文件内存溢出 ✗

【关键改动】
==========
1. docling_worker.py 中添加模型缓存机制
2. convert.py 中简化子进程调用逻辑
3. 改进内存释放和错误处理
"""

import os
import re
import sys
import json
import tempfile
import subprocess
import traceback
from pathlib import Path
from typing import Optional, Tuple, List
from concurrent.futures import ThreadPoolExecutor, as_completed

from config import (
    SOURCE_DIR, OUTPUT_MD_DIR, SUPPORTED_EXTENSIONS, CODE_CONFIG_EXTENSIONS,
    SOURCE_EXT_MARKER_PREFIX,
    CONVERT_WORKERS, MAX_MD_FILE_SIZE_KB, CONVERT_TIMEOUT,
)
from validate import is_file_readable
from state import compute_sha256
from docx.opc.exceptions import PackageNotFoundError

# 模块级 /dev/null 句柄
_DEVNULL = open(os.devnull, "w")

# ============================================================
# Worker 路径
# ============================================================
_WORKER_PATH = Path(__file__).parent / "docling_worker.py"


# ============================================================
# 工具函数
# ============================================================

def _get_rel_path(source_path: Path) -> str:
    return source_path.relative_to(SOURCE_DIR).as_posix()


def _get_output_md_path(source_path: Path) -> Path:
    rel = source_path.relative_to(SOURCE_DIR)
    return OUTPUT_MD_DIR / rel.with_suffix(".md")


def _ensure_output_dir(output_path: Path):
    """确保输出目录存在"""
    output_path.parent.mkdir(parents=True, exist_ok=True)


# ============================================================
# Docling 转换（子进程隔离）
# ============================================================

def _convert_with_docling(source_path: Path, output_path: Path) -> Tuple[str, Optional[str], Optional[str]]:
    """
    用 Docling 转换文档（支持 docx/pdf/xlsx/pptx），隔离在子进程中运行。
    
    子进程中会缓存 Docling 模型，避免每个文件都重新加载。
    返回 (status, error, warning)。
    """
    import tempfile
    
    rf = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
    rf.close()
    result_file = rf.name

    try:
        result = subprocess.run(
            [sys.executable, str(_WORKER_PATH),
             str(source_path), str(output_path), result_file],
            capture_output=True,
            timeout=CONVERT_TIMEOUT,
        )

        if result.returncode != 0:
            if result.returncode < 0:
                return ("error", f"Docling 子进程被信号 {-result.returncode} 杀死（段错误）", None)
            stderr_msg = result.stderr.decode('utf-8', 'ignore') if result.stderr else ""
            return ("error", f"Docling 子进程异常退出 (exitcode={result.returncode}) {stderr_msg[:200]}", None)

        # 读取子进程的结果
        try:
            with open(result_file, encoding='utf-8') as f:
                result_data = json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            return ("error", f"无法读取转换结果: {e}", None)

        if result_data.get("status") == "error":
            return ("error", f"Docling: {result_data.get('error', '未知错误')}", None)

    except subprocess.TimeoutExpired:
        return ("error", f"Docling 子进程超时（>{CONVERT_TIMEOUT}s），已强制终止", None)
    except Exception as e:
        return ("error", f"调用 Docling 子进程失败: {type(e).__name__}: {e}", None)
    finally:
        try:
            os.unlink(result_file)
        except OSError:
            pass

    # 子进程成功，读取输出文件
    try:
        md_content = output_path.read_text(encoding="utf-8")
    except Exception as e:
        return ("error", f"无法读取转换输出: {e}", None)

    if not md_content.strip():
        return ("empty", "Docling 转换内容为空", None)

    # 清理内容
    md_content = _clean_md_content(md_content)
    if not md_content.strip():
        return ("empty", "内容为空（移除了所有模板段落）", None)

    # 写回并检查大小
    try:
        _ensure_output_dir(output_path)
        output_path.write_text(md_content, encoding="utf-8")
    except Exception as e:
        return ("error", f"写入输出文件失败: {e}", None)

    warning = _check_md_size(output_path)
    return ("ok", None, warning)


# ============================================================
# MD 内容清洁
# ============================================================

def _check_md_size(md_path: Path) -> Optional[str]:
    """MD 文件超过阈值时返回预警信息。"""
    if md_path.exists():
        size_kb = md_path.stat().st_size / 1024
        if size_kb > MAX_MD_FILE_SIZE_KB:
            return f"MD 文件过大 ({size_kb:.0f}KB)，可能影响入库性能"
    return None


# 需要移除的单行模式
_BOILERPLATE_LINE_PATTERNS = [
    re.compile(r'^#+\s*(前\s*言|引言|概述|背景|前\s*言\s*$)'),
    re.compile(r'^#+\s*(目\s*录|目录|Contents)'),
    re.compile(r'(版权|著作权|著作权声明|版权声明|©\s*\d{4})'),
    re.compile(r'(All\s+rights?\s+reserved)', re.IGNORECASE),
    re.compile(r'(Confidential|机密|秘密|绝密)'),
    re.compile(r'(版本\s*[：:]|版\s*本\s*[：:]|版\s*本\s*号)'),
    re.compile(r'(修订记录|修\s*订\s*记\s*录|变更记录|变更历史|修订历史|文档变更)'),
    re.compile(r'^(作者|编写[：:]?|编制[：:]?|审核[：:]?|批准[：:]?|校对[：:]?|会审[：:]?|评审[：:]?|起草[：:]?|复核[：:]?)'),
    re.compile(r'^(第\s*\d+\s*页|Page\s+\d+|—\s*\d+\s*—|-\s*\d+\s*-)$'),
    re.compile(r'^中兴通讯|^ZTE\s*CORPORATION|^ZTE\s*中兴'),
    re.compile(r'^(技术文件|技术手册|产品文档|产品手册|用户手册|操作指南)'),
]

_TOC_HEADING = re.compile(r'^#+\s*[目\t ]*[录録]\s*$|^[#\s]*目录|^[#\s]*Contents')


def _clean_md_content(md_content: str) -> str:
    """移除模板段落、目录等"""
    lines = md_content.split('\n')
    cleaned = []
    skip_until_heading = False

    for i, line in enumerate(lines):
        raw = line.strip()

        # 目录段落检测
        if _TOC_HEADING.match(raw):
            skip_until_heading = True
            continue

        if skip_until_heading:
            if raw.startswith('#'):
                skip_until_heading = False
            else:
                continue

        # 单行模式匹配
        if any(pattern.search(raw) for pattern in _BOILERPLATE_LINE_PATTERNS):
            continue

        cleaned.append(line)

    return '\n'.join(cleaned).strip()


# ============================================================
# 降级解析（原生库）
# ============================================================

def _docx_to_md_fallback(source_path: Path, output_path: Path) -> Tuple[str, Optional[str], Optional[str]]:
    """Python-docx 降级方案（当 Docling 失败时）"""
    try:
        from docx import Document
        doc = Document(str(source_path))
        md_lines = []

        for para in doc.paragraphs:
            text = para.text.strip()
            if text:
                md_lines.append(text)

        for table in doc.tables:
            md_lines.append("")
            for row in table.rows:
                cells = [cell.text.strip().replace("\n", " ") for cell in row.cells]
                md_lines.append("| " + " | ".join(cells) + " |")
            md_lines.append("")

        md_content = "\n\n".join(md_lines).strip()
        if not md_content:
            return ("empty", None, "python-docx 解析结果为空")

        _ensure_output_dir(output_path)
        output_path.write_text(md_content, encoding="utf-8")
        return ("ok", None, "使用 python-docx 降级方案")

    except Exception as e:
        return ("error", f"python-docx 降级失败: {type(e).__name__}: {e}", None)


def _pdf_to_md_fallback(source_path: Path, output_path: Path) -> Tuple[str, Optional[str], Optional[str]]:
    """PyPDF 降级方案"""
    try:
        from PyPDF2 import PdfReader
        reader = PdfReader(str(source_path))
        text_lines = []

        for page_num, page in enumerate(reader.pages):
            text = page.extract_text()
            if text.strip():
                text_lines.append(f"## 页面 {page_num + 1}\n")
                text_lines.append(text)

        md_content = "\n\n".join(text_lines).strip()
        if not md_content:
            return ("empty", None, "PyPDF 解析结果为空")

        _ensure_output_dir(output_path)
        output_path.write_text(md_content, encoding="utf-8")
        return ("ok", None, "使用 PyPDF 降级方案")

    except Exception as e:
        return ("error", f"PyPDF 降级失败: {type(e).__name__}: {e}", None)


# ============================================================
# 单文件转换
# ============================================================

def convert_single_file(source_path: Path) -> dict:
    """
    转换单个文件（主函数）。
    
    返回:
      {
        "rel_path": "相对路径",
        "status": "ok|error|empty|skip",
        "md_path": "输出 markdown 相对路径或 None",
        "error": "错误信息或 None",
        "warning": "警告信息或 None",
        "sha256": "源文件哈希",
        "size": 文件大小,
        "mtime": 修改时间,
      }
    """
    rel_path = _get_rel_path(source_path)
    output_path = _get_output_md_path(source_path)

    result = {
        "rel_path": rel_path,
        "status": "error",
        "md_path": None,
        "error": None,
        "warning": None,
        "sha256": "",
        "size": 0,
        "mtime": "",
    }

    # 基本检查
    if not source_path.exists():
        result["error"] = "源文件不存在"
        return result

    if not is_file_readable(source_path):
        result["error"] = "文件无法读取"
        return result

    # 获取文件信息
    try:
        stat = source_path.stat()
        result["size"] = stat.st_size
        result["sha256"] = compute_sha256(source_path)
        result["mtime"] = stat.st_mtime
    except Exception as e:
        result["error"] = f"无法获取文件信息: {e}"
        return result

    # 按扩展名处理
    ext = source_path.suffix.lower()

    try:
        if ext == ".md":
            # Markdown 直接复制
            _ensure_output_dir(output_path)
            output_path.write_text(source_path.read_text(encoding="utf-8"), encoding="utf-8")
            result["status"] = "ok"
            result["md_path"] = output_path.relative_to(SOURCE_DIR).as_posix()

        elif ext == ".txt":
            # 文本文件，尝试多种编码
            for encoding in ["utf-8", "gbk", "gb2312", "latin-1"]:
                try:
                    content = source_path.read_text(encoding=encoding)
                    _ensure_output_dir(output_path)
                    output_path.write_text(content, encoding="utf-8")
                    result["status"] = "ok"
                    result["md_path"] = output_path.relative_to(SOURCE_DIR).as_posix()
                    break
                except (UnicodeDecodeError, LookupError):
                    continue

        elif ext in (".docx", ".pdf", ".xlsx", ".pptx"):
            # 首先尝试 Docling（主方案）
            status, error, warning = _convert_with_docling(source_path, output_path)
            
            # 如果 Docling 失败，尝试降级方案
            if status != "ok" and ext == ".docx":
                status, _, warning = _docx_to_md_fallback(source_path, output_path)
            elif status != "ok" and ext == ".pdf":
                status, _, warning = _pdf_to_md_fallback(source_path, output_path)

            result["status"] = status
            result["error"] = error
            result["warning"] = warning
            
            if status == "ok" and output_path.exists():
                result["md_path"] = output_path.relative_to(SOURCE_DIR).as_posix()

        else:
            result["error"] = f"不支持的文件格式: {ext}"

    except Exception as e:
        result["status"] = "error"
        result["error"] = f"处理异常: {type(e).__name__}: {e}"
        result["error"] += f"\n{traceback.format_exc()[:200]}"

    return result


# ============================================================
# 批量转换
# ============================================================

def convert_batch(file_paths: List[Path],
                  max_workers: int = CONVERT_WORKERS,
                  timeout: int = CONVERT_TIMEOUT,
                  progress_callback=None) -> List[dict]:
    """批量转换文件，支持进度回调"""
    results = []

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(convert_single_file, fp): fp for fp in file_paths}

        try:
            for future in as_completed(futures, timeout=timeout + 60):
                try:
                    result = future.result()
                    results.append(result)
                    if progress_callback:
                        progress_callback(result)
                except Exception as e:
                    fp = futures[future]
                    rel = _get_rel_path(fp)
                    results.append({
                        "rel_path": rel,
                        "status": "error",
                        "error": f"执行失败: {e}",
                    })

        except Exception as e:
            pass  # 超时或其他错误

    return results


if __name__ == "__main__":
    # 测试
    print("doc2kb convert 模块已加载（优化版）")
