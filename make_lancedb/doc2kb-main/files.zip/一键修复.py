#!/usr/bin/env python3
"""
doc2kb 性能问题一键修复脚本

功能：
  1. 自动备份现有文件
  2. 自动替换为修复版本
  3. 清理旧版本文件
  4. 验证修复完成

使用：
  python 一键修复.py

或指定项目路径：
  python 一键修复.py /path/to/project
"""

import sys
import shutil
from pathlib import Path
import json

def print_header(text):
    """打印标题"""
    print(f"\n{'='*60}")
    print(f"  {text}")
    print(f"{'='*60}\n")

def print_ok(text):
    """打印成功"""
    print(f"✓ {text}")

def print_error(text):
    """打印错误"""
    print(f"✗ {text}")
    sys.exit(1)

def print_warn(text):
    """打印警告"""
    print(f"⚠ {text}")

def main():
    # 确定项目路径
    if len(sys.argv) > 1:
        project_dir = Path(sys.argv[1])
    else:
        project_dir = Path.cwd()
    
    build_dir = project_dir / "make_lancedb" / "doc2kb-main"
    
    print_header("doc2kb 转换性能修复")
    print(f"项目目录: {project_dir}")
    print(f"构建目录: {build_dir}\n")
    
    # 检查目录
    if not build_dir.exists():
        print_error(f"找不到构建目录: {build_dir}")
    
    # 第 1 步：备份现有文件
    print_header("第 1 步：备份现有文件")
    
    convert_file = build_dir / "convert.py"
    if convert_file.exists():
        backup_file = build_dir / "convert.py.backup"
        shutil.copy2(convert_file, backup_file)
        print_ok(f"convert.py 已备份为 convert.py.backup")
    
    docling_file = build_dir / "docling_worker.py"
    convert_worker_file = build_dir / "convert_worker.py"
    
    # 第 2 步：检查修复文件
    print_header("第 2 步：检查修复文件")
    
    # 查找修复文件（同级目录）
    script_dir = Path(__file__).parent
    convert_fixed = script_dir / "convert_FIXED.py"
    docling_fixed = script_dir / "docling_worker_FIXED.py"
    
    if not convert_fixed.exists():
        print_error(f"找不到修复文件: {convert_fixed}")
    
    if not docling_fixed.exists():
        print_error(f"找不到修复文件: {docling_fixed}")
    
    print_ok(f"修复文件已找到")
    
    # 第 3 步：替换文件
    print_header("第 3 步：替换为修复版本")
    
    try:
        shutil.copy2(convert_fixed, convert_file)
        print_ok(f"convert.py 已替换")
        
        shutil.copy2(docling_fixed, docling_file)
        print_ok(f"docling_worker.py 已替换")
    except Exception as e:
        print_error(f"文件替换失败: {e}")
    
    # 第 4 步：清理旧版本文件
    print_header("第 4 步：清理旧版本文件")
    
    if convert_worker_file.exists():
        convert_worker_file.unlink()
        print_ok("convert_worker.py 已删除")
    else:
        print_warn("convert_worker.py 不存在（已清理）")
    
    # 第 5 步：验证修复
    print_header("第 5 步：验证修复")
    
    # 检查 convert.py 是否为旧版本
    convert_content = convert_file.read_text()
    
    checks = [
        ("包含 _convert_with_docling 函数", "_convert_with_docling" in convert_content),
        ("包含 subprocess.run", "subprocess.run" in convert_content),
        ("包含 _WORKER_PATH", "_WORKER_PATH" in convert_content),
    ]
    
    all_ok = True
    for check_name, result in checks:
        if result:
            print_ok(check_name)
        else:
            print_warn(f"未检测到: {check_name}")
            all_ok = False
    
    # 最终总结
    print_header("修复完成！")
    
    print("后续步骤:\n")
    print("1. 清理转换缓存（可选）:")
    print("   rm -rf make_lancedb/output_md/*.md\n")
    
    print("2. 重新构建:")
    print("   cd make_lancedb/doc2kb-main")
    print("   python doc_pipeline.py build --full\n")
    
    print("3. 测试问题文件:")
    print('   python doc_pipeline.py build \\')
    print('     --file "硬件安装/ZXVMAX-iDS-SAV7.25 硬件安装指导_R1.0.pdf"\n')
    
    print("备份文件位置:")
    print(f"  {build_dir / 'convert.py.backup'}\n")
    
    print("如需回退修改:")
    print(f"  cp {build_dir / 'convert.py.backup'} {convert_file}\n")
    
    if all_ok:
        print_ok("所有检查通过！修复成功！")
    else:
        print_warn("部分检查未通过，请检查文件内容")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
