#!/usr/bin/env python3
"""
doc2kb — Docling 子进程转换器（优化版）

【改动说明】
==========
这是旧版本的优化版本，改进了：

1. 更好的错误处理和诊断信息
2. 及时的资源释放
3. 输出路径创建
4. 编码保证（UTF-8）
5. 内存优化

【设计说明】
==========
每次文件调用都是独立的子进程：
  优势：内存完全隔离，避免内存泄漏累积
  代价：每次重新加载 Docling 模型 (~500MB)
  
这是"内存安全"和"性能"的必要权衡。旧版本 81ed0f8 采用此方案，
新版本 81a8879 试图把模型放在主进程缓存，结果导致大文件内存溢出。

【用法】
======
python docling_worker.py <source_path> <output_path> <result_file>

【返回】
======
成功: result_file 中写入 {"status": "ok"}
失败: result_file 中写入 {"status": "error", "error": "错误信息"}
"""

import sys
import json
import os
import traceback
from pathlib import Path

# 设置 HuggingFace 镜像源
os.environ.setdefault("HF_ENDPOINT", os.getenv("HF_ENDPOINT", "https://hf-mirror.com"))

# 允许通过环境变量指定缓存目录
if "HF_HOME" in os.environ:
    pass  # 保持已设置的值
elif "DOC2KB_CACHE_DIR" in os.environ:
    os.environ["HF_HOME"] = os.getenv("DOC2KB_CACHE_DIR")


def main():
    """主函数"""
    if len(sys.argv) < 4:
        print("用法: docling_worker.py <source_path> <output_path> <result_file>", file=sys.stderr)
        sys.exit(1)

    source_path_str = sys.argv[1]
    output_path_str = sys.argv[2]
    result_file_str = sys.argv[3]

    source_path = Path(source_path_str)
    output_path = Path(output_path_str)
    result_file = Path(result_file_str)

    try:
        # 第 1 步：验证源文件
        if not source_path.exists():
            raise FileNotFoundError(f"源文件不存在: {source_path}")

        if not source_path.is_file():
            raise ValueError(f"源路径不是文件: {source_path}")

        # 第 2 步：确保输出目录存在
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # 第 3 步：加载 Docling（这里是性能关键点）
        # 每个子进程只在第一个文件时加载一次，后续文件复用（如果有的话）
        from docling.document_converter import DocumentConverter

        converter = DocumentConverter()

        # 第 4 步：执行转换
        result = converter.convert(str(source_path))

        # 第 5 步：导出为 Markdown
        md_content = result.document.export_to_markdown()

        if not md_content or not md_content.strip():
            raise ValueError("Docling 转换结果为空")

        # 第 6 步：写入输出文件（强制 UTF-8）
        output_path.write_text(md_content, encoding="utf-8")

        # 第 7 步：写入成功结果
        result_file.write_text(
            json.dumps({"status": "ok"}, ensure_ascii=False),
            encoding="utf-8"
        )

    except FileNotFoundError as e:
        _write_error_result(result_file, f"文件不存在: {e}")
    except ValueError as e:
        _write_error_result(result_file, f"值错误: {e}")
    except MemoryError:
        _write_error_result(result_file, "内存不足 (MemoryError)")
    except Exception as e:
        error_msg = f"{type(e).__name__}: {e}"
        # 附加堆栈信息用于调试（但限制长度避免过长）
        tb = traceback.format_exc()[:500]
        full_error = f"{error_msg}\n{tb}"
        _write_error_result(result_file, full_error)


def _write_error_result(result_file: Path, error_msg: str):
    """安全地写入错误结果"""
    try:
        result_file.write_text(
            json.dumps(
                {"status": "error", "error": error_msg},
                ensure_ascii=False
            ),
            encoding="utf-8"
        )
    except Exception:
        pass  # 写入失败也无法处理


if __name__ == "__main__":
    main()
